__version__ = '1.3.0'

# Todo List:
# -----------------------------------------------------------------------------
# - add error notification: email or WhatsApp
# - add BSEC library for bme680
# -----------------------------------------------------------------------------

import os
import sys
import signal
import time
import datetime
import traceback
import logging
import configparser
import subprocess
from threading import Thread

import RPi.GPIO as GPIO
import board
import adafruit_tsl2591
import adafruit_ccs811
import adafruit_bme680
from adafruit_bme280 import basic as adafruit_bme280
from adafruit_seesaw.seesaw import Seesaw
from influxdb import InfluxDBClient
from RPLCD.i2c import CharLCD

# Initialize Logging
logging.basicConfig(filename=os.path.join(os.path.dirname(__file__), 'sgh.log'), level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s %(message)s')
gpio_logger = logging.getLogger('gpio')
gpio_logger.setLevel(logging.INFO)

timelapse_logger = logging.getLogger("timelapse")
timelapse_logger.setLevel(logging.INFO)

main_logger = logging.getLogger("main")
main_logger.setLevel(logging.INFO)

sensor_logger = logging.getLogger("sensor")
sensor_logger.setLevel(logging.INFO)

class GPIOHandler:
    def __init__(self):
        self.buttons = []
        self.relays = []

    def initialize(self):
        try:
            GPIO.setmode(GPIO.BCM)
        except RuntimeError:
            gpio_logger.error("GPIO mode already set. Skipping...")

        config = configparser.ConfigParser()

        with open(os.path.join(os.path.dirname(__file__), 'sgh.conf'), 'r') as config_file:
            config.read_file(config_file)

        if 'gpio' in config:
            buttons = config.get('gpio', 'buttons', fallback='')
            relays = config.get('gpio', 'relays', fallback='')

            if not buttons and not relays:
                gpio_logger.error("No buttons or relays configured. Exiting program.")
                main_logger.info("*** Program ended. ***")
                sys.exit(1)

            if buttons:
                self.buttons = [int(x.strip()) for x in buttons.split(',')]
                if len(self.buttons) < 3:
                    gpio_logger.error("Number of buttons is less than 3. Exiting program.")
                    main_logger.info("*** Program ended. ***")
                    sys.exit(1)
                for button in self.buttons:
                    GPIO.setup(button, GPIO.IN, pull_up_down=GPIO.PUD_UP)
                    gpio_logger.info(f"Button {button} configured.")
                    GPIO.add_event_detect(button, GPIO.FALLING, callback=self.button_pressed, bouncetime=300)

            if relays:
                self.relays = [int(x.strip()) for x in relays.split(',')]
                if len(self.relays) < 3:
                    gpio_logger.error("Number of relays is less than 3. Exiting program.")
                    main_logger.info("*** Program ended. ***")
                    sys.exit(1)
                for relay in self.relays:
                    GPIO.setup(relay, GPIO.OUT, initial=GPIO.HIGH)
                    gpio_logger.info(f"Relay {relay} configured.")
            return self.buttons, self.relays

        else:
            gpio_logger.error("No GPIO configuration found in the config. Exiting program.")
            main_logger.info("*** Program ended. ***")
            sys.exit(1)

    def button_pressed(self, channel):
        gpio_logger.info(f"Button {channel} pressed")
        if GPIO.input(self.buttons[-2]) == GPIO.LOW and GPIO.input(self.buttons[-1]) == GPIO.LOW:
            main_logger.info("Shutting down...")
            main_logger.info("*** Program ended. ***")
            subprocess.run(["sync"])
            subprocess.run(["sudo", "shutdown", "-h", "now"])
        button_index = self.buttons.index(channel)
        relay_status = not GPIO.input(self.relays[button_index])
        GPIO.output(self.relays[button_index], relay_status)

    @staticmethod
    def cleanup():
        try:
            gpio_logger.info("Cleaning up GPIOs...")
            GPIO.cleanup()
            gpio_logger.info("GPIOs cleaned up.")
        except RuntimeError:
            gpio_logger.warning("No channels have been set up yet - nothing to clean up.")

class SensorHandler:
    def __init__(self):
        self.bme280 = None
        self.bme680 = None
        self.tsl2591 = None
        self.ccs811 = None
        self.ss1 = None
        self.ss2 = None

    def initialize(self):
        try:
            i2c = board.I2C()
            self.bme280 = adafruit_bme280.Adafruit_BME280_I2C(i2c, address=0x76)
            self.bme680 = adafruit_bme680.Adafruit_BME680_I2C(i2c)
            self.tsl2591 = adafruit_tsl2591.TSL2591(i2c)
            self.ccs811 = adafruit_ccs811.CCS811(i2c)
            self.ss1 = Seesaw(i2c, addr=0x36)
            self.ss2 = Seesaw(i2c, addr=0x37)
            sensor_logger.info("Finished initializing sensors.")
        except Exception as e:
            main_logger.error(f"Error initializing sensors: {e}")
            main_logger.info("*** Program ended. ***")
            sys.exit(1)

    def read_sensors(self):
        sensor_data = {}
        sensors = {
            "bme280": {
                "temperature": lambda: self.bme280.temperature,
                "relative_humidity": lambda: float(self.bme280.relative_humidity),
                "pressure": lambda: self.bme280.pressure,
                "altitude": lambda: self.bme280.altitude,
            },
            "bme680": {
                "temperature": lambda: self.bme680.temperature,
                "relative_humidity": lambda: float(self.bme680.relative_humidity),
                "pressure": lambda: self.bme680.pressure,
                "altitude": lambda: self.bme680.altitude,
                "gas": lambda: float(self.bme680.gas),
            },
            "tsl2591": {
                "lux": lambda: float(self.tsl2591.lux),
                "infrared": lambda: float(self.tsl2591.infrared),
                "visible": lambda: float(self.tsl2591.visible),
                "full_spectrum_light": lambda: float(self.tsl2591.full_spectrum),
            },
            "ccs811": {
                "eco2": lambda: float(self.ccs811.eco2),
                "tvoc": lambda: float(self.ccs811.tvoc),
            },
            "ss1": {
                "moisture": lambda: float(self.ss1.moisture_read()),
                "temperature": lambda: float(self.ss1.get_temp()),
            },
            "ss2": {
                "moisture": lambda: float(self.ss2.moisture_read()),
                "temperature": lambda: float(self.ss2.get_temp()),
            },
        }

        for sensor_name, measurements in sensors.items():
            sensor_data[sensor_name] = {}
            for measurement_name, measurement_func in measurements.items():
                try:
                    sensor_data[sensor_name][measurement_name] = measurement_func()
                except Exception as e:
                    sensor_logger.error(f"Error reading {sensor_name} {measurement_name}: {e}")
                    sensor_logger.error(f"Exception type: {type(e)}")
                    sensor_logger.error(f"Traceback: {traceback.format_exc()}")
                    sensor_data[sensor_name][measurement_name] = None
        return sensor_data

def send_data_to_influxdb(sensor_data, client):
    data_points = []

    for sensor, measurements in sensor_data.items():
        point = {
            "measurement": sensor,
            "fields": measurements
        }
        data_points.append(point)

    client.write_points(data_points)

def read_and_send_sensor_data(sensor_handler, influxdb_client):
    while True:
        try:
            sensor_data = sensor_handler.read_sensors()
            send_data_to_influxdb(sensor_data, influxdb_client)
        except OSError as e:
            main_logger.error(f"I/O error while reading sensors: {e}")
        except Exception as e:
            main_logger.error(f"Unexpected error in read_and_send_sensor_data thread: {e}")
            main_logger.error(f"Exception type: {type(e)}")
            main_logger.error(f"Traceback: {traceback.format_exc()}")
        time.sleep(10)

def display_data(influxdb_client, lcd, active_from_hour, active_to_hour):
    while True:
        try:
            current_hour = datetime.datetime.now().hour

            if active_from_hour <= current_hour < active_to_hour:
                # Query the database for the last values of temperature, humidity, pressure and moisture
                query_last = "SELECT last(temperature), last(relative_humidity), last(pressure) FROM bme680 ORDER BY time DESC LIMIT 1"
                ss_query_last = "SELECT last(moisture) FROM ss1 ORDER BY time DESC LIMIT 1"

                result_last = influxdb_client.query(query_last)
                ss_result_last = influxdb_client.query(ss_query_last)
                points_last = list(result_last.get_points())
                ss_points_last = list(ss_result_last.get_points())

                # Query the database for the mean values of temperature, humidity, pressure and moisutre over the last 5 minutes
                query_mean = "SELECT mean(temperature), mean(relative_humidity), mean(pressure) FROM bme680 WHERE time > now() - 5m"
                ss_query_mean = "SELECT mean(moisture) FROM ss1 WHERE time > now() - 5m"

                result_mean = influxdb_client.query(query_mean)
                ss_result_mean = influxdb_client.query(ss_query_mean)
                points_mean = list(result_mean.get_points())
                ss_points_mean = list(ss_result_mean.get_points())

                if points_last and points_mean and ss_points_last and ss_points_mean:
                    temperature_last = points_last[0]['last']
                    humidity_last = points_last[0]['last_1']
                    pressure_last = points_last[0]['last_2']
                    moisture_last = ss_points_last[0]['last']

                    temperature_mean = points_mean[0]['mean']
                    humidity_mean = points_mean[0]['mean_1']
                    pressure_mean = points_mean[0]['mean_2']
                    moisture_mean = ss_points_mean[0]['mean']

                    # Display the values on the LCD screen
                    lcd.backlight_enabled = True
                    lcd.clear()
                    lcd.cursor_pos = (0, 0)
                    lcd.write_string(f"T: {temperature_last:.1f} {chr(223)}C {temperature_mean:.1f}")
                    lcd.cursor_pos = (1, 0)
                    lcd.write_string(f"H: {humidity_last:.1f} % {humidity_mean:.1f}")
                    lcd.cursor_pos = (2, 0)
                    lcd.write_string(f"P: {pressure_last:.1f} hPa {pressure_mean:.1f}")
                    lcd.cursor_pos = (3, 0)
                    lcd.write_string(f"M: {moisture_last:.0f} | {moisture_mean:.0f}")
                else:
                    lcd.backlight_enabled = True
                    lcd.clear()
                    lcd.cursor_pos = (0, 0)
                    lcd.write_string("No data available")

            else:
                lcd.backlight_enabled = False

            time.sleep(10)

        except Exception as e:
            main_logger.error(f"Error in display data thread: {e}")
            time.sleep(10)

def initialize_influxdb(config):
    if 'influxdb' not in config:
        main_logger.warning("No InfluxDB configuration found in the config. Using fallback configuration: localhost:8086, sghdb.")
        influxdb_config = {
            'host': 'localhost',
            'port': '8086',
            'database': 'sghdb'
        }
    else:
        influxdb_config = config['influxdb']

    influxdb_client = InfluxDBClient(
        host=influxdb_config.get('host', fallback='localhost'),
        port=int(influxdb_config.get('port', fallback='8086')),
        database=influxdb_config.get('database', fallback='sghdb')
    )

    try:
        influxdb_client.ping()
        databases = influxdb_client.get_list_database()
        if influxdb_config['database'] not in [db['name'] for db in databases]:
            influxdb_client.create_database(influxdb_config['database'])
            main_logger.info(f"InfluxDB database '{influxdb_config['database']}' created.")
    except Exception as e:
        main_logger.error(f"Failed to connect to InfluxDB: {e}")
        main_logger.info("*** Program ended. ***")
        sys.exit(1)

    return influxdb_client

def grow_control(gpio_handler, active_from_hour, active_to_hour, influxdb_client):
    while True:
        try:
            now = datetime.datetime.now()
            if active_from_hour <= now.hour < active_to_hour:
                GPIO.output(gpio_handler.relays[0], GPIO.LOW)
                GPIO.output(gpio_handler.relays[2], GPIO.LOW)

                # Get the last 5 minutes average of humidity from InfluxDB
                query = "SELECT MEAN(relative_humidity) FROM bme680 WHERE time >= now() - 5m"
                result = influxdb_client.query(query)
                humidity = next(result.get_points())['mean']
                if humidity > 70:
                    GPIO.output(gpio_handler.relays[4], GPIO.LOW)
                else:
                    GPIO.output(gpio_handler.relays[4], GPIO.HIGH)

            else:
                GPIO.output(gpio_handler.relays[0], GPIO.HIGH)
                time.sleep(1)
                GPIO.output(gpio_handler.relays[2], GPIO.HIGH)

            time.sleep(60)
        except Exception as e:
            # Log the error to the main logging logger
            main_logging.error(f"Error in grow control thread: {e}")

def capture_timelapse(gpio_handler, photo_path, timelapse_from_hour, timelapse_to_hour):
    while True:
        try:
            current_time = datetime.datetime.now()
            current_hour = current_time.hour

            if timelapse_from_hour <= current_hour < timelapse_to_hour:
                filename = current_time.strftime('%Y-%m-%d_%H-%M-%S') + '.jpg'

                relay1_status = GPIO.input(gpio_handler.relays[0])
                GPIO.output(gpio_handler.relays[0], GPIO.LOW)
                GPIO.output(gpio_handler.relays[1], GPIO.LOW)
                time.sleep(2)

                # Check if the video device is already in use
                lsof_process = subprocess.run(['sudo', 'lsof', '/dev/video0', '|', 'grep', '/dev/video0'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                if lsof_process.returncode == 0:
                    timelapse_logger.error('Video device is already in use by another process.')
                    timelapse_logger.error(f'lsof output: {lsof_process.stdout.decode()}') # Log the lsof output to the log file
                    time.sleep(60)
                    continue

                try:
                    retries = 0
                    while retries < 3:
                        process = subprocess.run(['sudo', 'fswebcam', '-r', '1280x720', '--no-banner', f'{photo_path}/{filename}'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                        if process.returncode == 0 and os.path.isfile(os.path.join(photo_path, filename)):
                            timelapse_logger.info(f"Photo captured: {photo_path}/{filename}")
                            break  # exit loop if photo is captured successfully
                        else:
                            retries += 1
                            timelapse_logger.error(f"Error capturing photo: {process.stderr.decode().strip()}")
                            lsof_process = subprocess.run(['sudo', 'lsof', '/dev/video0', '|', 'grep', '/dev/video0'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                            timelapse_logger.error(f'lsof output: {lsof_process.stdout.decode()}') # Log the lsof output to the log file
                            time.sleep(60)  # wait for 1 minute before retrying
                    if retries == 3:
                        timelapse_logger.error("Failed to capture photo after 3 retries.")
                except Exception as e:
                    timelapse_logger.error(f'Error capturing photo: {e}')

                time.sleep(1)
                GPIO.output(gpio_handler.relays[0], relay1_status)
                GPIO.output(gpio_handler.relays[1], GPIO.HIGH)

            time.sleep(3600 - current_time.second - current_time.microsecond / 1000000)
        except Exception as e:
            # Log the error to the timelapse logger
            timelapse_logger.error(f"Error in capture timelapse thread: {e}")

def signal_handler(sig, frame):
    GPIOHandler.cleanup()
    main_logger.info(f"Received signal {sig}")
    main_logger.info("*** Program ended. ***")
    sys.exit(0)

def main():
    main_logger.info("*** Program started. ***")

    signal.signal(signal.SIGTERM, signal_handler)

    # Read configuration
    config = configparser.ConfigParser()
    with open(os.path.join(os.path.dirname(__file__), 'sgh.conf'), 'r') as config_file:
        config.read_file(config_file)

    # Initialize GPIO
    gpio_handler = GPIOHandler()
    buttons, relays = gpio_handler.initialize()

    # Initialize Sensors
    sensor_handler = SensorHandler()
    sensor_handler.initialize()

    # Initialize InfluxDB client
    influxdb_client = initialize_influxdb(config)

    # Initialize LCD2004
    lcd = CharLCD(i2c_expander='PCF8574', address=0x27, port=1, cols=20, rows=4, dotsize=8, charmap='A02', auto_linebreaks=True)

    # Start the read and send sensor data thread
    read_and_send_thread = Thread(target=read_and_send_sensor_data, args=(sensor_handler, influxdb_client), daemon=True)
    read_and_send_thread.start()

    if 'active_hours' in config:
        active_from_hour = config.getint('active_hours', 'from_hour', fallback=7)
        active_to_hour = config.getint('active_hours', 'to_hour', fallback=20)
    else:
        active_from_hour = 7
        active_to_hour = 20
        main_logger.warning("No active_hours configured. Using fallback configuration: 7, 20")

    if 'timelapse' in config:
        photo_path = config.get('timelapse', 'photo_path', fallback='/home/pi/photos')
        timelapse_from_hour = config.getint('timelapse', 'from_hour', fallback=7)
        timelapse_to_hour = config.getint('timelapse', 'to_hour', fallback=20)
    else:
        photo_path = '/home/pi/photos'
        timelapse_from_hour = 7
        timelapse_to_hour = 20
        main_logger.warning("No timelapse configured. Using fallback configuration: /home/pi/photos, 7, 20")

    try:
        if not os.path.exists(photo_path):
            os.makedirs(photo_path)
            main_logger.info(f"Photo directory '{photo_path}' doesn't exist, creating...")
    except Exception as e:
        main_logger.error(f"Error creating directory '{photo_path}': {e}")
        main_logger.info("*** Program ended. ***")
        sys.exit(1)

    # Start the grow control thread
    grow_control_thread = Thread(target=grow_control, args=(gpio_handler, active_from_hour, active_to_hour, influxdb_client), daemon=True)
    grow_control_thread.start()

    # Start the capture timelapse thread
    capture_timalaps_thread = Thread(target=capture_timelapse, args=(gpio_handler, photo_path, timelapse_from_hour, timelapse_to_hour), daemon=True)
    capture_timalaps_thread.start()

    # Start the display data thread
    display_data_thread = Thread(target=display_data, args=(influxdb_client, lcd, active_from_hour, active_to_hour), daemon=True)
    display_data_thread.start()

    # Log the initial status of each thread
    if grow_control_thread.is_alive():
        main_logger.info("The grow control thread is running.")
    if capture_timalaps_thread.is_alive():
        main_logger.info("The capture timelapse thread is running.")
    if display_data_thread.is_alive():
        main_logger.info("The display data thread is running.")

    try:

        while True:

            # Monitor the threads

            # Check the status of the grow control thread
            if not grow_control_thread.is_alive():
                main_logger.error("The grow control thread has stopped.")

            # Check the status of the capture timelapse thread
            if not capture_timalaps_thread.is_alive():
                main_logger.error("The capture timelapse thread has stopped.")

            # Check the status of the display data thread
            if not display_data_thread.is_alive():
                main_logger.error("The display data thread has stopped.")

            time.sleep(10)

    except KeyboardInterrupt:
        main_logger.info("KeyboardInterrupt received. Exiting program.")
        GPIOHandler.cleanup()
        main_logger.info("*** Program ended. ***")
        sys.exit(0)

    except Exception as e:
        main_logger.error(f"Unexpected error: {e}")
        GPIOHandler.cleanup()
        main_logger.info("*** Program ended. ***")
        sys.exit(1)

if __name__ == "__main__":
    main()
